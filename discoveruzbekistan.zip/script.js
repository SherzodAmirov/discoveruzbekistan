/* script.js for discoveruzbekistan */
let state = { lang: 'uz', currency: 'UZS', usdRate: 13000 };

// Utility: format currency based on state
function formatCurrency(amountUZS){
  if(state.currency === 'UZS') return amountUZS.toLocaleString() + " so'm";
  const usd = amountUZS / state.usdRate;
  return usd.toFixed(2) + ' $';
}
const DATA = {
  "nature": [
    {
      "id": "charvak",
      "title": {
        "uz": "Charvak",
        "ru": "Charvak",
        "en": "Charvak"
      },
      "region": "Various",
      "img": "images/charvak.jpg",
      "desc": {
        "uz": "Charvak haqida qisqacha.",
        "ru": "Charvak - кратко.",
        "en": "Charvak short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "chimyon",
      "title": {
        "uz": "Chimyon & Beldersoy",
        "ru": "Chimyon & Beldersoy",
        "en": "Chimyon & Beldersoy"
      },
      "region": "Various",
      "img": "images/chimyon.jpg",
      "desc": {
        "uz": "Chimyon & Beldersoy haqida qisqacha.",
        "ru": "Chimyon & Beldersoy - кратко.",
        "en": "Chimyon & Beldersoy short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "amirsoy",
      "title": {
        "uz": "Amirsoy",
        "ru": "Amirsoy",
        "en": "Amirsoy"
      },
      "region": "Various",
      "img": "images/amirsoy.jpg",
      "desc": {
        "uz": "Amirsoy haqida qisqacha.",
        "ru": "Amirsoy - кратко.",
        "en": "Amirsoy short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "zaamin",
      "title": {
        "uz": "Zaamin National Park",
        "ru": "Zaamin National Park",
        "en": "Zaamin National Park"
      },
      "region": "Various",
      "img": "images/zaamin.jpg",
      "desc": {
        "uz": "Zaamin National Park haqida qisqacha.",
        "ru": "Zaamin National Park - кратко.",
        "en": "Zaamin National Park short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "aydarkul",
      "title": {
        "uz": "Aydarkul Lake",
        "ru": "Aydarkul Lake",
        "en": "Aydarkul Lake"
      },
      "region": "Various",
      "img": "images/aydarkul.jpg",
      "desc": {
        "uz": "Aydarkul Lake haqida qisqacha.",
        "ru": "Aydarkul Lake - кратко.",
        "en": "Aydarkul Lake short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "muynoq",
      "title": {
        "uz": "Muynoq — Aral Sea",
        "ru": "Muynoq — Aral Sea",
        "en": "Muynoq — Aral Sea"
      },
      "region": "Various",
      "img": "images/muynoq.jpg",
      "desc": {
        "uz": "Muynoq — Aral Sea haqida qisqacha.",
        "ru": "Muynoq — Aral Sea - кратко.",
        "en": "Muynoq — Aral Sea short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "nuratau",
      "title": {
        "uz": "Nuratau Mountains",
        "ru": "Nuratau Mountains",
        "en": "Nuratau Mountains"
      },
      "region": "Various",
      "img": "images/nuratau.jpg",
      "desc": {
        "uz": "Nuratau Mountains haqida qisqacha.",
        "ru": "Nuratau Mountains - кратко.",
        "en": "Nuratau Mountains short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "sarmish",
      "title": {
        "uz": "Sarmishsay",
        "ru": "Sarmishsay",
        "en": "Sarmishsay"
      },
      "region": "Various",
      "img": "images/sarmish.jpg",
      "desc": {
        "uz": "Sarmishsay haqida qisqacha.",
        "ru": "Sarmishsay - кратко.",
        "en": "Sarmishsay short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "shoximardon",
      "title": {
        "uz": "Shokhimardon",
        "ru": "Shokhimardon",
        "en": "Shokhimardon"
      },
      "region": "Various",
      "img": "images/shoximardon.jpg",
      "desc": {
        "uz": "Shokhimardon haqida qisqacha.",
        "ru": "Shokhimardon - кратко.",
        "en": "Shokhimardon short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "omonqoton",
      "title": {
        "uz": "Omonqoton",
        "ru": "Omonqoton",
        "en": "Omonqoton"
      },
      "region": "Various",
      "img": "images/omonqoton.jpg",
      "desc": {
        "uz": "Omonqoton haqida qisqacha.",
        "ru": "Omonqoton - кратко.",
        "en": "Omonqoton short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "kyzylkum",
      "title": {
        "uz": "Kyzylkum Desert",
        "ru": "Kyzylkum Desert",
        "en": "Kyzylkum Desert"
      },
      "region": "Various",
      "img": "images/kyzylkum.jpg",
      "desc": {
        "uz": "Kyzylkum Desert haqida qisqacha.",
        "ru": "Kyzylkum Desert - кратко.",
        "en": "Kyzylkum Desert short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "chatkal",
      "title": {
        "uz": "Chatkal National Park",
        "ru": "Chatkal National Park",
        "en": "Chatkal National Park"
      },
      "region": "Various",
      "img": "images/chatkal.jpg",
      "desc": {
        "uz": "Chatkal National Park haqida qisqacha.",
        "ru": "Chatkal National Park - кратко.",
        "en": "Chatkal National Park short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "fergana",
      "title": {
        "uz": "Fergana Valley",
        "ru": "Fergana Valley",
        "en": "Fergana Valley"
      },
      "region": "Various",
      "img": "images/fergana.jpg",
      "desc": {
        "uz": "Fergana Valley haqida qisqacha.",
        "ru": "Fergana Valley - кратко.",
        "en": "Fergana Valley short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "parkent",
      "title": {
        "uz": "Parkent Gorge",
        "ru": "Parkent Gorge",
        "en": "Parkent Gorge"
      },
      "region": "Various",
      "img": "images/parkent.jpg",
      "desc": {
        "uz": "Parkent Gorge haqida qisqacha.",
        "ru": "Parkent Gorge - кратко.",
        "en": "Parkent Gorge short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "beldersay",
      "title": {
        "uz": "Beldersay",
        "ru": "Beldersay",
        "en": "Beldersay"
      },
      "region": "Various",
      "img": "images/beldersay.jpg",
      "desc": {
        "uz": "Beldersay haqida qisqacha.",
        "ru": "Beldersay - кратко.",
        "en": "Beldersay short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "aydarkul2",
      "title": {
        "uz": "Aydarkul Region",
        "ru": "Aydarkul Region",
        "en": "Aydarkul Region"
      },
      "region": "Various",
      "img": "images/aydarkul2.jpg",
      "desc": {
        "uz": "Aydarkul Region haqida qisqacha.",
        "ru": "Aydarkul Region - кратко.",
        "en": "Aydarkul Region short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "sarmish2",
      "title": {
        "uz": "Sarmishsay Rocks",
        "ru": "Sarmishsay Rocks",
        "en": "Sarmishsay Rocks"
      },
      "region": "Various",
      "img": "images/sarmish2.jpg",
      "desc": {
        "uz": "Sarmishsay Rocks haqida qisqacha.",
        "ru": "Sarmishsay Rocks - кратко.",
        "en": "Sarmishsay Rocks short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "shoximardon2",
      "title": {
        "uz": "Shokhimardon Peaks",
        "ru": "Shokhimardon Peaks",
        "en": "Shokhimardon Peaks"
      },
      "region": "Various",
      "img": "images/shoximardon2.jpg",
      "desc": {
        "uz": "Shokhimardon Peaks haqida qisqacha.",
        "ru": "Shokhimardon Peaks - кратко.",
        "en": "Shokhimardon Peaks short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    }
  ],
  "historic": [
    {
      "id": "registon",
      "title": {
        "uz": "Registon (Samarkand)",
        "ru": "Registon (Samarkand)",
        "en": "Registon (Samarkand)"
      },
      "region": "Various",
      "img": "images/registon.jpg",
      "desc": {
        "uz": "Registon (Samarkand) haqida qisqacha.",
        "ru": "Registon (Samarkand) - кратко.",
        "en": "Registon (Samarkand) short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "guremir",
      "title": {
        "uz": "Gur-e Amir",
        "ru": "Gur-e Amir",
        "en": "Gur-e Amir"
      },
      "region": "Various",
      "img": "images/guremir.jpg",
      "desc": {
        "uz": "Gur-e Amir haqida qisqacha.",
        "ru": "Gur-e Amir - кратко.",
        "en": "Gur-e Amir short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "shahizinda",
      "title": {
        "uz": "Shohi Zinda",
        "ru": "Shohi Zinda",
        "en": "Shohi Zinda"
      },
      "region": "Various",
      "img": "images/shahizinda.jpg",
      "desc": {
        "uz": "Shohi Zinda haqida qisqacha.",
        "ru": "Shohi Zinda - кратко.",
        "en": "Shohi Zinda short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "bibikhanym",
      "title": {
        "uz": "Bibi-Khanym Mosque",
        "ru": "Bibi-Khanym Mosque",
        "en": "Bibi-Khanym Mosque"
      },
      "region": "Various",
      "img": "images/bibikhanym.jpg",
      "desc": {
        "uz": "Bibi-Khanym Mosque haqida qisqacha.",
        "ru": "Bibi-Khanym Mosque - кратко.",
        "en": "Bibi-Khanym Mosque short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "ulugbek",
      "title": {
        "uz": "Ulug'bek Observatory",
        "ru": "Ulug'bek Observatory",
        "en": "Ulug'bek Observatory"
      },
      "region": "Various",
      "img": "images/ulugbek.jpg",
      "desc": {
        "uz": "Ulug'bek Observatory haqida qisqacha.",
        "ru": "Ulug'bek Observatory - кратко.",
        "en": "Ulug'bek Observatory short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "itchanqala",
      "title": {
        "uz": "Itchan Qala (Khiva)",
        "ru": "Itchan Qala (Khiva)",
        "en": "Itchan Qala (Khiva)"
      },
      "region": "Various",
      "img": "images/itchanqala.jpg",
      "desc": {
        "uz": "Itchan Qala (Khiva) haqida qisqacha.",
        "ru": "Itchan Qala (Khiva) - кратко.",
        "en": "Itchan Qala (Khiva) short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "arkbukhara",
      "title": {
        "uz": "Ark Fortress (Bukhara)",
        "ru": "Ark Fortress (Bukhara)",
        "en": "Ark Fortress (Bukhara)"
      },
      "region": "Various",
      "img": "images/arkbukhara.jpg",
      "desc": {
        "uz": "Ark Fortress (Bukhara) haqida qisqacha.",
        "ru": "Ark Fortress (Bukhara) - кратко.",
        "en": "Ark Fortress (Bukhara) short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "kalon",
      "title": {
        "uz": "Kalon Minaret",
        "ru": "Kalon Minaret",
        "en": "Kalon Minaret"
      },
      "region": "Various",
      "img": "images/kalon.jpg",
      "desc": {
        "uz": "Kalon Minaret haqida qisqacha.",
        "ru": "Kalon Minaret - кратко.",
        "en": "Kalon Minaret short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "shahrisabz",
      "title": {
        "uz": "Shahrisabz Historic Center",
        "ru": "Shahrisabz Historic Center",
        "en": "Shahrisabz Historic Center"
      },
      "region": "Various",
      "img": "images/shahrisabz.jpg",
      "desc": {
        "uz": "Shahrisabz Historic Center haqida qisqacha.",
        "ru": "Shahrisabz Historic Center - кратко.",
        "en": "Shahrisabz Historic Center short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "samanid",
      "title": {
        "uz": "Samanid Mausoleum",
        "ru": "Samanid Mausoleum",
        "en": "Samanid Mausoleum"
      },
      "region": "Various",
      "img": "images/samanid.jpg",
      "desc": {
        "uz": "Samanid Mausoleum haqida qisqacha.",
        "ru": "Samanid Mausoleum - кратко.",
        "en": "Samanid Mausoleum short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "chorminor",
      "title": {
        "uz": "Chor Minor",
        "ru": "Chor Minor",
        "en": "Chor Minor"
      },
      "region": "Various",
      "img": "images/chorminor.jpg",
      "desc": {
        "uz": "Chor Minor haqida qisqacha.",
        "ru": "Chor Minor - кратко.",
        "en": "Chor Minor short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "lyabihauz",
      "title": {
        "uz": "Lyab-i-Hauz",
        "ru": "Lyab-i-Hauz",
        "en": "Lyab-i-Hauz"
      },
      "region": "Various",
      "img": "images/lyabihauz.jpg",
      "desc": {
        "uz": "Lyab-i-Hauz haqida qisqacha.",
        "ru": "Lyab-i-Hauz - кратко.",
        "en": "Lyab-i-Hauz short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "pahlavon",
      "title": {
        "uz": "Pahlavon Mahmud Mausoleum",
        "ru": "Pahlavon Mahmud Mausoleum",
        "en": "Pahlavon Mahmud Mausoleum"
      },
      "region": "Various",
      "img": "images/pahlavon.jpg",
      "desc": {
        "uz": "Pahlavon Mahmud Mausoleum haqida qisqacha.",
        "ru": "Pahlavon Mahmud Mausoleum - кратко.",
        "en": "Pahlavon Mahmud Mausoleum short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "hazrati",
      "title": {
        "uz": "Hazrati Imam Complex",
        "ru": "Hazrati Imam Complex",
        "en": "Hazrati Imam Complex"
      },
      "region": "Various",
      "img": "images/hazrati.jpg",
      "desc": {
        "uz": "Hazrati Imam Complex haqida qisqacha.",
        "ru": "Hazrati Imam Complex - кратко.",
        "en": "Hazrati Imam Complex short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "termez",
      "title": {
        "uz": "Termez Sites",
        "ru": "Termez Sites",
        "en": "Termez Sites"
      },
      "region": "Various",
      "img": "images/termez.jpg",
      "desc": {
        "uz": "Termez Sites haqida qisqacha.",
        "ru": "Termez Sites - кратко.",
        "en": "Termez Sites short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "nukus",
      "title": {
        "uz": "Nukus Savitsky Museum",
        "ru": "Nukus Savitsky Museum",
        "en": "Nukus Savitsky Museum"
      },
      "region": "Various",
      "img": "images/nukus.jpg",
      "desc": {
        "uz": "Nukus Savitsky Museum haqida qisqacha.",
        "ru": "Nukus Savitsky Museum - кратко.",
        "en": "Nukus Savitsky Museum short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "tashmetro",
      "title": {
        "uz": "Tashkent Metro (art)",
        "ru": "Tashkent Metro (art)",
        "en": "Tashkent Metro (art)"
      },
      "region": "Various",
      "img": "images/tashmetro.jpg",
      "desc": {
        "uz": "Tashkent Metro (art) haqida qisqacha.",
        "ru": "Tashkent Metro (art) - кратко.",
        "en": "Tashkent Metro (art) short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    },
    {
      "id": "oldcity",
      "title": {
        "uz": "Old City Sites",
        "ru": "Old City Sites",
        "en": "Old City Sites"
      },
      "region": "Various",
      "img": "images/oldcity.jpg",
      "desc": {
        "uz": "Old City Sites haqida qisqacha.",
        "ru": "Old City Sites - кратко.",
        "en": "Old City Sites short info."
      },
      "distance_km": 100,
      "est_cost_uzs": 200000
    }
  ]
};

// I18n strings
const I18N = {
  uz: { title:'Oʻzbekistondagi Tabiat va Tarixiy Joylar', subtitle:'Sayohat uchun toʻliq maʼlumot', natureTitle:'Tabiat joylari', historicTitle:'Tarixiy joylar', mapTitle:'Xaritada ko‘rish', mapHelp:'Agar kerak bo\'lsa, men aniq Google Maps embed linklarini qo\'shaman.', galleryTitle:'Galereya', contactTitle:'Aloqa', contactText:'Savollar: +998 90 123 45 67 · info@discoveruzbekistan.uz' },
  ru: { title:'Природа и исторические места Узбекистана', subtitle:'Полная информация для путешествий', natureTitle:'Природные места', historicTitle:'Исторические места', mapTitle:'Посмотреть на карте', mapHelp:'Если нужно, добавлю точные ссылки Google Maps для каждого места.', galleryTitle:'Галерея', contactTitle:'Контакты', contactText:'Вопросы: +998 90 123 45 67 · info@discoveruzbekistan.uz' },
  en: { title:'Nature and Historical Sites of Uzbekistan', subtitle:'Complete travel info', natureTitle:'Nature spots', historicTitle:'Historical sites', mapTitle:'View on map', mapHelp:'If needed, I can add exact Google Maps embed links for each place.', galleryTitle:'Gallery', contactTitle:'Contact', contactText:'Questions: +998 90 123 45 67 · info@discoveruzbekistan.uz' }
};

// Renderers
function translate(key){
  const map = { more: {uz:'Batafsil',ru:'Подробнее',en:'More'}, mapBtn: {uz:'Xaritada ko\'rish',ru:'Посмотреть на карте',en:'View on map'}, close: {uz:'Yopish',ru:'Закрыть',en:'Close'} };
  return map[key] ? map[key][state.lang] : key;
}

function renderCards(){
  const nContainer = document.getElementById('natureList');
  const hContainer = document.getElementById('historicList');
  nContainer.innerHTML = '';
  hContainer.innerHTML = '';

  DATA.nature.forEach(place=>{
    const div = document.createElement('article'); div.className='card';
    div.innerHTML = `
      <img src="${place.img}" alt="${place.id}" onerror="this.src='images/placeholder.jpg'" />
      <div class='body'>
        <h3>${place.title[state.lang]}</h3>
        <p>${place.desc[state.lang]}</p>
        <p><strong>Hudud:</strong> ${place.region} · <strong>Masofa:</strong> ${place.distance_km} km</p>
        <p><strong>Taxminiy xarajat:</strong> ${formatCurrency(place.est_cost_uzs || 0)}</p>
        <a class='btn' href='#' data-id='${place.id}' data-type='nature'>${translate('more')}</a>
      </div>
    `;
    nContainer.appendChild(div);
  });

  DATA.historic.forEach(place=>{
    const div = document.createElement('article'); div.className='card';
    div.innerHTML = `
      <img src="${place.img}" alt="${place.id}" onerror="this.src='images/placeholder.jpg'" />
      <div class='body'>
        <h3>${place.title[state.lang]}</h3>
        <p>${place.desc[state.lang]}</p>
        <p><strong>Hudud:</strong> ${place.region}</p>
        <p><strong>Kirish narxi:</strong> ${formatCurrency(place.entry_uzs || 0)}</p>
        <a class='btn' href='#' data-id='${place.id}' data-type='historic'>${translate('more')}</a>
      </div>
    `;
    hContainer.appendChild(div);
  });
}

function applyI18n(){
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const k = el.getAttribute('data-i18n');
    if(I18N[state.lang][k]) el.innerText = I18N[state.lang][k];
  });
  document.querySelectorAll('.btn').forEach(b=>{ b.innerText = translate('more'); });
}

// Fetch real-time exchange rate (uses exchangerate.host). Sets state.usdRate to so'm per 1 USD.
async function fetchUsdRate(){
  try{
    // Prefer USD->UZS then set usdRate = UZS per 1 USD
    const res = await fetch('https://api.exchangerate.host/latest?base=USD&symbols=UZS');
    const data = await res.json();
    if(data && data.rates && data.rates.UZS){
      state.usdRate = data.rates.UZS;
    }
  }catch(err){
    console.warn('Could not fetch exchange rate, using fallback', err);
    state.usdRate = 13000;
  }
}

document.addEventListener('DOMContentLoaded', async ()=>{
  document.getElementById('langSelect').value = state.lang;
  document.getElementById('currencySelect').value = state.currency;

  document.getElementById('langSelect').addEventListener('change', e=>{
    state.lang = e.target.value;
    renderCards(); applyI18n();
  });

  document.getElementById('currencySelect').addEventListener('change', e=>{
    state.currency = e.target.value;
    renderCards();
  });

  document.body.addEventListener('click', (e)=>{
    if(e.target.matches('.btn')){
      e.preventDefault();
      const id = e.target.dataset.id; const type = e.target.dataset.type;
      openDetail(id, type);
    }
  });

  await fetchUsdRate();
  renderCards(); applyI18n();

  // Gallery
  const galleryGrid = document.getElementById('galleryGrid');
  const imgs = [];
  DATA.nature.concat(DATA.historic).forEach(p=>{ imgs.push(p.img); });
  imgs.forEach(src=>{
    const im = document.createElement('img'); im.src=src; im.alt=''; im.addEventListener('click', ()=>openLightbox(src));
    galleryGrid.appendChild(im);
  });
});

function openLightbox(src){
  const lb = document.getElementById('lightbox'); lb.innerHTML = '';
  const img = document.createElement('img'); img.src = src; lb.appendChild(img); lb.style.display='flex';
  lb.addEventListener('click', ()=>{ lb.style.display='none'; });
}

function openDetail(id, type){
  const list = type === 'nature' ? DATA.nature : DATA.historic;
  const place = list.find(p=>p.id===id);
  if(!place) return alert('Not found');

  const modal = document.createElement('div'); modal.className='lightbox';
  const content = document.createElement('div'); content.style.maxWidth='900px'; content.style.padding='18px'; content.style.background='#fff'; content.style.borderRadius='12px';
  content.innerHTML = `
    <h2>${place.title[state.lang]}</h2>
    <img src='${place.img}' style='width:100%;height:320px;object-fit:cover;border-radius:8px' onerror="this.src='images/placeholder.jpg'" />
    <p>${place.desc[state.lang]}</p>
    <p><strong>Hudud:</strong> ${place.region}</p>
    ${place.distance_km ? `<p><strong>Masofa:</strong> ${place.distance_km} km</p>` : ''}
    ${place.est_cost_uzs ? `<p><strong>Taxminiy xarajat:</strong> ${formatCurrency(place.est_cost_uzs)}</p>` : ''}
    ${place.entry_uzs ? `<p><strong>Kirish narxi:</strong> ${formatCurrency(place.entry_uzs)}</p>` : ''}
    <p><button id='openMapBtn'>${translate('mapBtn')}</button> <button id='closeModal'>${translate('close')}</button></p>
  `;
  modal.appendChild(content);
  document.body.appendChild(modal);

  document.getElementById('closeModal').addEventListener('click', ()=>document.body.removeChild(modal));
  document.getElementById('openMapBtn').addEventListener('click', ()=>{ alert('Map iframe-ni sozlash uchun menga ruxsat bering — men aniq coordinates qo\'shaman.'); });
}
