discoveruzbekistan — static site package
======================================

Contents:
- index.html
- styles.css
- script.js
- places/ (individual pages for each listed place)
- images/ (placeholder images for every place)
- README (this file)

How to run locally:
1. Unzip the package.
2. Open index.html in your browser (double-click). The site is fully static and runs without a server.

Images:
- These are placeholder images generated automatically. Replace images/<name>.jpg with real photos (keep same filename) if you want to customize.

Google Maps:
- The place pages use a generic Google Maps embed (`q=PLACE_NAME&output=embed`). For precise locations, replace iframe src with the exact "Share -> Embed a map" URL from Google Maps.

Currency API:
- script.js uses exchangerate.host to fetch USD->UZS rate.
- If you deploy on GitHub Pages, the request should work, but some browsers or environments may block CORS. If so, consider using a simple server-side proxy or a different API.

Deploying (GitHub Pages):
1. Create a new GitHub repository.
2. Upload all files (or `git init && git add . && git commit -m "initial" && git remote add origin ... && git push`).
3. In GitHub repo Settings -> Pages, choose branch 'main' and root '/'. Save.
4. Your site will be available at https://YOURUSERNAME.github.io/REPO_NAME/

Deploying (Netlify):
1. Sign up at netlify.com and create new site from Git.
2. Choose your repo and set build settings (none for plain static site).
3. Deploy — Netlify gives a public URL.

If you want, I can:
- Replace placeholder images with curated HD photos I find (I can prepare them and include with proper attribution).
- Replace generic map iframes with precise embed links for every place.
- Package the ZIP here again with updated images and exact map embeds.

Enjoy!